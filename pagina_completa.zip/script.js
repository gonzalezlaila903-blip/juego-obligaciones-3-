
function generarJuego() {
    const texto = document.getElementById("resumen").value.trim();
    const tipo = document.getElementById("tipoJuego").value;
    const zona = document.getElementById("juego");

    if (!texto) {
        zona.innerHTML = "<p>⚠ Cargá un resumen primero.</p>";
        return;
    }

    const frases = texto.split(".").filter(t => t.length > 20);

    if (tipo === "quiz") {
        zona.innerHTML = "<h2>Quiz</h2>" + frases.slice(0,3).map((f,i)=>
        `<p><b>Pregunta ${i+1}:</b> ${f.split(" ").slice(0,8).join(" ")}...</p>`).join("");
    }

    if (tipo === "vf") {
        zona.innerHTML = "<h2>Verdadero / Falso</h2>" + frases.slice(0,4).map(f=> 
        `<p>${f} — ¿V o F?</p>`).join("");
    }

    if (tipo === "flash") {
        zona.innerHTML = "<h2>Flashcards</h2>" + frases.slice(0,5).map((f,i)=> 
        `<div class='card'><b>${i+1}:</b> ${f}</div>`).join("");
    }

    if (tipo === "memoria") {
        zona.innerHTML = "<h2>Memoria</h2><p>(Versión básica textual)</p>" +
        frases.slice(0,6).map(f=> `<p>🧩 ${f.split(" ")[0]}</p>`).join("");
    }

    if (tipo === "drag") {
        zona.innerHTML = "<h2>Ordenar Conceptos</h2>" +
        frases.slice(0,4).map(f=> `<div draggable='true' class='draggable'>${f.split(" ").slice(0,5).join(" ")}</div>`).join("");
    }
}
